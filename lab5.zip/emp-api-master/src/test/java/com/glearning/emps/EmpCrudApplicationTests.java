package com.glearning.emps;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
